<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

App::uses('AppController', 'Controller');

/**
 * CakePHP UsersController
 * @author u15031
 */
class UsersController extends AppController {

    public function index() {
        return $this->redirect(array('controller' => 'users', 'action' => 'login'));
    }

    public function login() {
        if ($this->request->is('post')) {
            $username = $this->request->data['User']['username'];
            $password = $this->request->data['User']['password'];

            $rec = $this->User->find('first', array('conditions' => array('username' => $username)));
           
            if ($rec) {
                $usr = $rec['User']['password'];
                $pass = $rec['User']['password'];

                if ($username == $usr && $password == $pass) {
                    return $this->redirect(array('controller' => 'products', 'action' => 'adminindex'));
                } elseif (!$username == $usr || !$password == $pass) {
                   return $this->redirect(array('controller' => 'products', 'action' => 'index'));
                }
            }
        }
    }

}
