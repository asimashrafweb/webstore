<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

App::uses('AppController', 'Controller');
App::uses('Folder', 'Utility');
App::uses('File', 'Utility');

/**
 * CakePHP ProductsController
 * @author u15031
 */
class ProductsController extends AppController {

    //var $uses = array('Product');
    //public $name = 'Product';
    var $helpers = array('Session');
    public $components = array('Paginator', 'Session', 'Email', 'RequestHandler');
    var $uses = array('Product');

    public function index() {
        $this->set('products', $this->Product->find('all'));
    }

    public function view($id) {
        if (!$this->Product->exists($id)) {
            throw new NotFoundException(__('Invalid product'));
        }

        $product = $this->Product->read(null, $id);
        $this->set(compact('product'));
    }

    public function adminindex() {
        $this->set('products', $this->Product->find('all'));
    }

    public function addNewItem() {

        if ($this->request->is('post')) {
            $this->Product->create();

            debug($this->request->data);
            $file = $this->request->data['Product']['image'];
            //print_r($file); exit();
            $file['name'] = $this->sanitize($file['name']);

            $this->request->data['Product']['image'] = '/img/' . $file['name'];
            debug($this->request->data);

            if ($this->Product->save($this->request->data)) {
                move_uploaded_file($file['tmp_name'], WWW_ROOT . DS . 'img' . DS . $file['name']);
                return $this->redirect(array('action' => 'adminindex'));
            } else {
                echo 'Not working';
                //$this->Session->setFlash(__('The item could not be saved. Please, try again.'));
            }
            //}
        }
    }

    function sanitize($string, $force_lowercase = true, $anal = false) {
        $strip = array("~", "`", "!", "@", "#", "$", "%", "^", "&", "*", "(", ")", "_", "=", "+", "[", "{", "]", "}", "\\", "|", ";", ":", "\"", "'", "&#8216;", "&#8217;", "&#8220;", "&#8221;", "&#8211;", "&#8212;", "â€”", "â€“", ",", "<", ">", "/", "?");
        $clean = trim(str_replace($strip, "", strip_tags($string)));
        $clean = preg_replace('/\s+/', "-", $clean);
        $clean = ($anal) ? preg_replace("/[^a-zA-Z0-9]/", "", $clean) : $clean;
        return ($force_lowercase) ?
                (function_exists('mb_strtolower')) ?
                        mb_strtolower($clean, 'UTF-8') :
                        strtolower($clean) :
                $clean;
    }

    public function edit($id = null) {
        if (empty($this->request->data)) {
            $this->request->data = $this->Product->read(NULL, $id);
        } else {
            $file = $this->request->data['Product']['image'];
            $file['name'] = $this->sanitize($file['name']);

            $this->request->data['Product']['image'] = '/img/' . $file['name'];
            if ($this->Product->save($this->request->data)) {
                move_uploaded_file($file['tmp_name'], WWW_ROOT . DS . 'img' . DS . $file['name']);
                $this->redirect(array('controller' => 'products', 'action' => 'adminindex'));
            }
        }
    }
    
    public function delete($id = null) {
        $this->Product->delete($id);
        $this->redirect(array('controller' => 'products', 'action' => 'adminindex'));
    }

}
