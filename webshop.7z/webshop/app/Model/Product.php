<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

App::uses('AppModel', 'Model');

/**
 * CakePHP Products
 * @author u15031
 */
class Product extends AppModel {
    var $name = 'Product';
    
    public $validate = array(
        'price' => array(
            'rule' => 'numeric',
            'message' => 'Please enter only numbers',
            'allowEmpty' => false,
            'required' => true
        ),
        'image' => array(
            'rule' => 
                array('extension', array('gif', 'jpeg', 'png', 'jpg'),
                'message' => 'Please supply a valid image.',
                ),
            'allowEmpty' => false
        ),
    );
    
}
